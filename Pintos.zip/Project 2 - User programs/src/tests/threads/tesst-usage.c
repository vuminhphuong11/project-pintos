#include "threads/threads.h"
#include "threads/synch.h"
#include "devices/timer.h"
#include "stdio.h"

// This function will report the CPU usage of the current thread.
void report_cpu_usage(void) {
    struct thread *t = thread_current();
    int64_t total_ticks = timer_ticks();  // Total system time in ticks
    
    if (total_ticks == 0) {
        printf("CPU usage not available. System ticks are zero.\n");
        return;
    }
    
    int cpu_usage_percent = (int) ((100 * t->cpu_usage_ticks) / total_ticks);
    
    printf("Thread '%s' CPU Usage: %d%%\n", t->name, cpu_usage_percent);
}

// This function will be run by a new thread to test CPU usage.
void cpu_usage_test_thread(void *aux UNUSED) {
    int i;
    
    // Loop for a while, simulating work, and report CPU usage periodically.
    for (i = 0; i < 10; i++) {
        report_cpu_usage();  // Report CPU usage of the current thread
        timer_sleep(100);    // Sleep for 100 ticks (100ms if tick rate is 100Hz)
    }
}

// Test function that creates a new thread and runs the cpu_usage_test_thread.
void cpu_usage_test(void) {
    // Create and run the CPU usage test thread
    printf("Starting CPU usage test...\n");
    thread_create("CPU-Usage-Test-Thread", PRI_DEFAULT, cpu_usage_test_thread, NULL);
    
    // Main thread also does some work (just for demonstration)
    int i;
    for (i = 0; i < 10; i++) {
        report_cpu_usage();  // Report CPU usage of the current (main) thread
        timer_sleep(200);    // Sleep for 200 ticks (200ms)
        thread_yield();      // Yield the CPU to other threads (give test thread a chance to run)
    }
    
    // Wait for the CPU usage test thread to finish
    printf("CPU usage test finished.\n");
}


